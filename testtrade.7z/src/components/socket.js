import io from "socket.io-client";

//const socket = io(`84.252.131.248:8000`);
const socket = io();
export default socket;

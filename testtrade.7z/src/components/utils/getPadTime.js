export const getPadTime = (num) => {
  return num.toString().padStart(2, 0);
};
